#include <iostream>
#include <vector>

using namespace std;
int max_tree = 0; 
/*
bool checking_for_S(vector<vector<int>>& park, int xstart, int ystart, int xend, int yend, int S){
    int sum = 0;
    for (int i = xstart; i <=  xend; i++){
        for (int j = ystart; j <=  yend; j++){
            if (park[i][j] == 2){
                sum++;
            }
        }
    }
    if (sum >= S){
        return true;
    }
    return false;
}
*/
int checking_tree( vector<vector<int>>& park, int N, int K, int L, int S){
    int size_of_park_max = N - K;
    for (int i = 0; i <= size_of_park_max; i++){
        for (int j = 0; j <= size_of_park_max; j++){
            int count_tree = 0;
            int count_S = 0;
            for (int x = i; x < i + K; x++){
                for (int y = j; y < j + K; y++){              // checking the park for the K x K square
                    if (x >= i + L && y >= j + L && x < i + K - L  && y < j + K - L ){        // checking the center of the park
                        if (park[x][y] == 2){
                            count_S++;
                            continue;
                        }
                    }
                    if(park[x][y] == 1){
                        count_tree++;
                    }
                }
            }
            if (count_S >= S && count_tree > max_tree){
                max_tree = count_tree;
            }
        } 
    }
    return max_tree;
}



int main (){
    int N, K, L, S;
    cin >> N >> K >> L >> S;

    vector<vector<int>> park(N, vector<int>(N)); // N x N matrix

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cin >> park[i][j]; // directly fill the matrix
        }
    }
    int result = checking_tree(park, N, K, L, S);
    cout << result << endl;
    

    return 0;
}
