#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int max_score = 0;
int N;
bool allVisited(vector<bool>& visited_vec) {
    for (int i = 1; i < N+1; i++) {
        if (!visited_vec[i]) return false; // if any is unvisited
    }
    return true; // all visited
}


void DFS(vector<vector<int>>& graph, int A, int B, vector<bool>& visited_vec, 
         int node, int placing_agent, vector<int>& agent_placed) {
    agent_placed[node] = placing_agent;
    visited_vec[node] = true;

    // Base case: when we used all agents
    if (allVisited(visited_vec) || (A<= 0 && B <= 0)) {
        int score = 0;
        for (int i = 1; i < N+1; i++) {
            if (agent_placed[i] == 1) { // A
                for (auto neighbor : graph[i]) {
                    if (agent_placed[neighbor] == 1 || agent_placed[neighbor] == 2) {
                        score++;
                    }
                }
            } 
            else if (agent_placed[i] == 2) { // B
                for (auto neighbor : graph[i]) {
                    if (agent_placed[neighbor] == 0) {
                        score++;
                    }
                }
            }
        }
        max_score = max(max_score, score);
        agent_placed[node] = 0;
        visited_vec[node] = false;
        return;
    }

    // Recurse to neighbors
    for (auto neighbor : graph[node]) {
        if (!visited_vec[neighbor]) {
            // Try leaving empty
            DFS(graph, A, B, visited_vec, neighbor, 0, agent_placed);
            // Try placing A
            if (A > 0) {
                DFS(graph, A-1, B, visited_vec, neighbor, 1, agent_placed);
            }
            // Try placing B
            if (B > 0) {
                DFS(graph, A, B-1, visited_vec, neighbor, 2, agent_placed);
            }
        }
    }

    // Backtrack
    agent_placed[node] = 0;
    visited_vec[node] = false;
}

int max_score_in_graph(vector<vector<int>>& graph, int A, int B) {
    vector<bool> visited_vec(N+1, false);

    vector<int> agent_placed(N+1, 0); // 0 - empty, 1 - A, 2 - B

    // Start DFS from node 1
    DFS(graph, A, B, visited_vec, 1, 0, agent_placed);
    if (A > 0) {
        DFS(graph, A-1, B, visited_vec, 1, 1, agent_placed);
    }
    if (B > 0) {
        DFS(graph, A, B-1, visited_vec, 1, 2, agent_placed);
    }

    return max_score;
}

int main() {
    int M, A, B;
    cin >> N >> M >> A >> B;

    vector<vector<int>> graph(N+1);

    // Read edges
    for (int i = 0; i < M; i++) {
        int u, v;
        cin >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }

    cout << max_score_in_graph(graph, A, B) << endl;
    return 0;
}
