#include <bits/stdc++.h>
using namespace std;
using ull = unsigned int; 
 
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
    int N, M, A, B;
    cin >> N >> M >> A >> B;
 
    vector<ull> adj(N, 0);
    vector<char> deg(N, 0);
 
    // Načtení hran
    for (int i = 0; i < M; ++i) {
        int u, v; cin >> u >> v;
        --u; --v;
        adj[u] |= (1ULL << v);
        adj[v] |= (1ULL << u);
        deg[u]++; deg[v]++;
    }
 
    int K = A + B;
    ull bestScore = 0;
    ull limit = ((1ULL << N) - 1ULL);
    ull comb = ((1ULL << K) - 1ULL);
    while (comb <= limit) {
        ull baseline = 0;
        vector<char> deltas; deltas.reserve(K);
        ull s = comb;
        while (s) {
            int v = __builtin_ctzll(s);
            s &= s - 1;
 
            int in_deg = __builtin_popcountll(adj[v] & comb);
            int out_deg = deg[v] - in_deg;
 
            baseline += out_deg;
            deltas.push_back(in_deg - out_deg);
        }
        if (!deltas.empty()) {
            int maxDelta = *max_element(deltas.begin(), deltas.end());
            if (baseline + (long long)A * maxDelta <= bestScore)
                goto next_combination;
        }        

        if (A > 0) {
            if ((char)deltas.size() <= A) {
                ull add = 0;
                for (char x : deltas) add += x;
                bestScore = max(bestScore, baseline + add);
            } else {
                nth_element(deltas.begin(), deltas.begin() + A, deltas.end(), greater<int>());
                ull add = 0;
                for (char i = 0; i < A; ++i) add += deltas[i];
                bestScore = max(bestScore, baseline + add);
            }
        } else {
            bestScore = max(bestScore, baseline);
        }
        next_combination:  
        if (comb == 0) break;
        ull c = comb & -comb;
        ull r = comb + c;
        if (r == 0) break;
        comb = (((r ^ comb) >> 2) / c) | r;
        if (comb > limit) break;
    }
 
    cout << bestScore << "\n";
    return 0;
}